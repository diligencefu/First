//
//  main.m
//  TopSelectBar
//
//  Created by apple on 2017/8/29.
//  Copyright © 2017年 付耀辉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
